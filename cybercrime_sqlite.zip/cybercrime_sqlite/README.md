# Cybercrime Complaint Intelligence System
Run (Windows): python -m venv venv -> venv\Scripts\activate -> pip install -r requirements.txt -> python setup_db.py -> python app.py -> open http://127.0.0.1:5000
Pages: / (file complaint) · /admin (dashboard) · /charts (analytics) · /complaint/<id> · /export_csv
