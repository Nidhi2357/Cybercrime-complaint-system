# ================================================================
#  CYBER CRIME COMPLAINT INTELLIGENCE SYSTEM - Fixed app.py
#  HOW TO RUN: python app.py
#  OPEN: http://127.0.0.1:5000
# ================================================================

from flask import Flask, render_template, request, redirect, url_for, flash, Response, jsonify
import sqlite3, os, csv, io, re, json, time
from werkzeug.utils import secure_filename
from datetime import datetime
from ml_classifier import ml_classify

app = Flask(__name__)
app.secret_key = "cybercrime_intel_2024"

UPLOAD_FOLDER = "static/uploads"
ALLOWED_EXTENSIONS = {"png","jpg","jpeg","gif","pdf","doc","docx"}
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
DATABASE = "cybercrime.db"

# ── Keyword fallback ──────────────────────────────────────────
CRIME_KEYWORDS = {
    "Online Fraud":      ["fraud","scam","money","transfer","upi","payment","bank","otp","lost","rupees","account","debit","credit","cash","paytm","phonepe","gpay"],
    "Phishing":          ["phishing","fake email","link","clicked","fake website","login","password","credentials","verify","account suspended","reset password"],
    "Cyberbullying":     ["bully","harass","threat","abusive","insult","troll","stalk","defame","humiliate","morphed","fake profile","rumour"],
    "Hacking":           ["hack","hacked","unauthorized","breach","account taken","gmail","facebook","instagram","locked out","compromised","keylogger"],
    "Identity Theft":    ["identity","aadhaar","pan","passport","document","loan","impersonate","fake id","personal details","kyc","sim swap"],
    "Ransomware":        ["ransomware","encrypt","locked","files","ransom","bitcoin","crypto","demand","virus","malware"],
    "Social Media Abuse":["instagram","facebook","twitter","whatsapp","youtube","fake profile","photo misuse","video leak","morphed photo","obscene"],
    "Data Breach":       ["data leak","personal data","database hacked","private info","dark web","data stolen","records exposed"],
}

def keyword_classify(description):
    text = description.lower()
    scores = {}
    for crime, keywords in CRIME_KEYWORDS.items():
        hits = sum(1 for kw in keywords if kw in text)
        if hits:
            scores[crime] = hits
    if not scores:
        return "Other", 0
    best = max(scores, key=scores.get)
    conf = min(int(scores[best] / len(CRIME_KEYWORDS[best]) * 100 * 3), 90)
    return best, conf

def classify_complaint(description):
    try:
        ml_type, ml_conf, _ = ml_classify(description)
        if ml_conf >= 40:
            return ml_type, int(ml_conf)
    except:
        pass
    return keyword_classify(description)

# ── Entity extraction ─────────────────────────────────────────
def extract_entities(text):
    if not text:
        return {}
    e = {}
    phones = re.findall(r'\b(?:\+91[\s\-]?)?[6-9]\d{9}\b', text)
    if phones: e["phone_numbers"] = list(set(phones))
    emails = re.findall(r'\b[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}\b', text)
    if emails: e["emails"] = list(set(emails))
    upis = re.findall(r'\b[\w.\-]+@(?:okaxis|okhdfcbank|okicici|oksbi|ybl|ibl|axl|upi|paytm|gpay|phonepe|apl|aubank)\b', text)
    if upis: e["upi_ids"] = list(set(upis))
    urls = re.findall(r'(?:https?://|www\.)[^\s<>"{}|\\^`\[\]]+', text)
    if urls: e["urls"] = list(set(urls))
    amounts = re.findall(r'(?:rs\.?|inr|₹)\s*[\d,]+(?:\.\d{1,2})?|\b[\d,]+(?:\.\d{1,2})?\s*(?:rs\.?|inr|rupees?)\b', text, re.IGNORECASE)
    if amounts: e["amounts"] = list(set([a.strip() for a in amounts]))
    return e

# ── Priority scoring ──────────────────────────────────────────
CRIME_BASE = {
    "Ransomware":9,"Identity Theft":8,"Hacking":7,"Online Fraud":7,
    "Data Breach":6,"Phishing":6,"Cyberbullying":5,"Social Media Abuse":4,"Other":3
}

def calculate_priority(description, crime_type, severity):
    text  = description.lower() if description else ""
    score = CRIME_BASE.get(crime_type, 3)
    if severity == "High":   score += 2
    elif severity == "Medium": score += 1
    reasons = []
    for kw in ["children","minor","suicide","death threat","terror","crore","lakh","hospital","blackmail","extortion","ransom","elderly"]:
        if kw in text:
            score += 1
            reasons.append(kw)
            break
    amounts = re.findall(r'(\d[\d,]*)\s*(?:rs|rupees?|inr|lakh|crore)', text, re.IGNORECASE)
    if amounts:
        try:
            mx = max([int(a.replace(',','')) for a in amounts])
            if mx >= 100000: score += 2; reasons.append(f"loss Rs {mx:,}")
            elif mx >= 10000: score += 1; reasons.append(f"loss Rs {mx:,}")
        except: pass
    score = max(1, min(score, 10))
    label = "Critical" if score >= 8 else "High" if score >= 6 else "Medium" if score >= 4 else "Low"
    return score, label, ", ".join(reasons) if reasons else "Standard assessment"

def get_db():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

def allowed_file(fn):
    return "." in fn and fn.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS

# ── ROUTES ────────────────────────────────────────────────────

@app.route("/")
def home():
    return render_template("landing.html")

@app.route("/report")
def report():
    return render_template("index.html")

@app.route("/submit", methods=["POST"])
def submit():
    fullname      = request.form.get("fullname", "").strip()
    email         = request.form.get("email", "").strip()
    phone         = request.form.get("phone", "").strip()
    city          = request.form.get("city", "").strip()
    crime_type    = request.form.get("crime_type", "").strip()
    incident_date = request.form.get("incident_date", "")
    description   = request.form.get("description", "").strip()
    severity      = request.form.get("severity", "Medium")

    start_time = time.time()
    if not crime_type:
        crime_type, confidence = classify_complaint(description)
    else:
        _, confidence = classify_complaint(description)

    entities = extract_entities(description)
    priority_score, priority_label, priority_reason = calculate_priority(description, crime_type, severity)
    triage_ms = round((time.time() - start_time) * 1000, 2)

    evidence_filename = None
    if "evidence" in request.files:
        file = request.files["evidence"]
        if file and file.filename != "" and allowed_file(file.filename):
            fn = f"{datetime.now().strftime('%Y%m%d_%H%M%S')}_{secure_filename(file.filename)}"
            file.save(os.path.join(app.config["UPLOAD_FOLDER"], fn))
            evidence_filename = fn

    try:
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO complaints
              (fullname,email,phone,city,crime_type,incident_date,description,
               severity,evidence_file,ai_confidence,entities_json,
               priority_score,priority_label,priority_reason,triage_ms)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """, (fullname,email,phone,city,crime_type,incident_date,description,
              severity,evidence_filename,confidence,json.dumps(entities),
              priority_score,priority_label,priority_reason,triage_ms))
        conn.commit()
        new_id = cursor.lastrowid
        conn.close()
        return redirect(url_for("thankyou", complaint_id=new_id))
    except Exception as e:
        flash(f"Error saving: {str(e)}", "error")
        return redirect(url_for("report"))

@app.route("/thankyou/<int:complaint_id>")
def thankyou(complaint_id):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT triage_ms, crime_type, priority_label, priority_score FROM complaints WHERE id=?", (complaint_id,))
    row = cursor.fetchone()
    conn.close()
    return render_template("thankyou.html", cid=complaint_id, row=row)

@app.route("/admin")
def admin():
    search   = request.args.get("search", "").strip()
    ft       = request.args.get("crime_type", "")
    fs       = request.args.get("status", "")
    fp       = request.args.get("priority", "")
    try:
        conn   = get_db()
        cursor = conn.cursor()

        q = "SELECT * FROM complaints WHERE 1=1"
        p = []
        if search:
            q += " AND (fullname LIKE ? OR city LIKE ? OR description LIKE ? OR crime_type LIKE ?)"
            p += [f"%{search}%"] * 4
        if ft: q += " AND crime_type=?";      p.append(ft)
        if fs: q += " AND status=?";          p.append(fs)
        if fp: q += " AND priority_label=?";  p.append(fp)
        q += " ORDER BY priority_score DESC, submitted_at DESC"

        cursor.execute(q, p)
        all_complaints = cursor.fetchall()

        # FIX: use [0] not .count to read COUNT(*) results
        cursor.execute("SELECT COUNT(*) FROM complaints")
        total = cursor.fetchone()[0]

        cursor.execute("SELECT COUNT(*) FROM complaints WHERE status='Pending'")
        pending = cursor.fetchone()[0]

        cursor.execute("SELECT COUNT(*) FROM complaints WHERE status='Investigating'")
        investigating = cursor.fetchone()[0]

        cursor.execute("SELECT COUNT(*) FROM complaints WHERE status='Resolved'")
        resolved = cursor.fetchone()[0]

        cursor.execute("SELECT COUNT(*) FROM complaints WHERE priority_label='Critical'")
        critical = cursor.fetchone()[0]

        cursor.execute("SELECT AVG(triage_ms) FROM complaints WHERE triage_ms > 0")
        avg_ms_row = cursor.fetchone()
        avg_ms = round(avg_ms_row[0], 1) if avg_ms_row and avg_ms_row[0] else 0

        conn.close()
        return render_template("admin.html",
            complaints=all_complaints, total=total, pending=pending,
            investigating=investigating, resolved=resolved, critical=critical,
            avg_ms=avg_ms, search=search,
            filter_type=ft, filter_status=fs, filter_priority=fp)

    except Exception as e:
        return f"<h2 style='color:red;padding:40px;font-family:sans-serif'>Error: {e}<br>Try running: python setup_db.py</h2>"

@app.route("/complaint/<int:cid>")
def view_complaint(cid):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM complaints WHERE id=?", (cid,))
    c = cursor.fetchone()
    conn.close()
    if not c:
        return "<h2 style='font-family:sans-serif;padding:40px'>Complaint not found</h2>"
    try:
        entities = json.loads(c["entities_json"]) if c["entities_json"] else {}
    except:
        entities = {}
    return render_template("complaint_detail.html", c=c, entities=entities)

@app.route("/update_status", methods=["POST"])
def update_status():
    cid = request.form.get("complaint_id")
    ns  = request.form.get("status")
    try:
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute("UPDATE complaints SET status=? WHERE id=?", (ns, cid))
        conn.commit()
        conn.close()
        flash("Status updated successfully!", "success")
    except Exception as e:
        flash(f"Error: {e}", "error")
    return redirect(url_for("admin"))

@app.route("/charts")
def charts():
    try:
        conn   = get_db()
        cursor = conn.cursor()

        cursor.execute("SELECT crime_type, COUNT(*) as c FROM complaints GROUP BY crime_type ORDER BY c DESC")
        crime_data = cursor.fetchall()

        cursor.execute("SELECT severity, COUNT(*) as c FROM complaints GROUP BY severity")
        severity_data = cursor.fetchall()

        cursor.execute("SELECT strftime('%Y-%m', submitted_at) as m, COUNT(*) as c FROM complaints GROUP BY m ORDER BY m ASC LIMIT 12")
        monthly_data = cursor.fetchall()

        cursor.execute("SELECT status, COUNT(*) as c FROM complaints GROUP BY status")
        status_data = cursor.fetchall()

        cursor.execute("SELECT city, COUNT(*) as c FROM complaints GROUP BY city ORDER BY c DESC LIMIT 5")
        city_data = cursor.fetchall()

        cursor.execute("SELECT priority_label, COUNT(*) as c FROM complaints GROUP BY priority_label ORDER BY c DESC")
        priority_data = cursor.fetchall()

        cursor.execute("SELECT COUNT(*) FROM complaints")
        total = cursor.fetchone()[0]

        cursor.execute("SELECT COUNT(*) FROM complaints WHERE severity='High'")
        high_count = cursor.fetchone()[0]

        cursor.execute("SELECT COUNT(*) FROM complaints WHERE priority_label='Critical'")
        critical_count = cursor.fetchone()[0]

        cursor.execute("SELECT AVG(priority_score) FROM complaints")
        avg_p_row = cursor.fetchone()
        avg_priority = round(avg_p_row[0], 1) if avg_p_row and avg_p_row[0] else 0

        cursor.execute("SELECT AVG(triage_ms) FROM complaints WHERE triage_ms > 0")
        avg_ms_row = cursor.fetchone()
        avg_ms = round(avg_ms_row[0], 1) if avg_ms_row and avg_ms_row[0] else 0

        cursor.execute("SELECT crime_type, COUNT(*) as c FROM complaints GROUP BY crime_type ORDER BY c DESC LIMIT 1")
        top_crime = cursor.fetchone()

        cursor.execute("SELECT city, COUNT(*) as c FROM complaints GROUP BY city ORDER BY c DESC LIMIT 1")
        top_city = cursor.fetchone()

        conn.close()

        return render_template("charts.html",
            crime_data=crime_data, severity_data=severity_data,
            monthly_data=monthly_data, status_data=status_data,
            city_data=city_data, priority_data=priority_data,
            top_crime=top_crime, top_city=top_city,
            total=total, high_count=high_count,
            critical_count=critical_count,
            avg_priority=avg_priority, avg_ms=avg_ms)

    except Exception as e:
        return f"<h2 style='color:red;padding:40px;font-family:sans-serif'>Charts Error: {e}</h2>"

@app.route("/ai_analyze", methods=["POST"])
def ai_analyze():
    desc = request.form.get("description", "")
    sev  = request.form.get("severity", "Medium")
    start = time.time()
    crime_type, confidence = classify_complaint(desc)
    entities = extract_entities(desc)
    ps, pl, pr = calculate_priority(desc, crime_type, sev)
    ms = round((time.time() - start) * 1000, 2)
    return jsonify({
        "crime_type": crime_type, "confidence": confidence,
        "priority_score": ps, "priority_label": pl,
        "priority_reason": pr, "entities": entities, "triage_ms": ms
    })

@app.route("/export_csv")
def export_csv():
    try:
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute("""SELECT id,fullname,email,phone,city,crime_type,incident_date,
            description,severity,ai_confidence,priority_score,priority_label,
            triage_ms,status,submitted_at FROM complaints ORDER BY priority_score DESC""")
        rows = cursor.fetchall()
        conn.close()

        output = io.StringIO()
        writer = csv.writer(output)
        writer.writerow(["ID","Name","Email","Phone","City","Crime Type","Date",
            "Description","Severity","AI Confidence%","Priority Score",
            "Priority Label","Triage Time(ms)","Status","Submitted At"])
        for row in rows:
            writer.writerow(list(row))
        output.seek(0)
        fn = f"complaints_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
        return Response(output.getvalue(), mimetype="text/csv",
            headers={"Content-Disposition": f"attachment; filename={fn}"})
    except Exception as e:
        flash(f"Export error: {e}", "error")
        return redirect(url_for("admin"))

if __name__ == "__main__":
    app.run(debug=True, port=5000)
