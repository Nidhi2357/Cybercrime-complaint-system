# ================================================================
#  ML CLASSIFIER - Pure Python (No scikit-learn needed)
#  Uses TF-IDF + Naive Bayes implemented from scratch
#  
#  WHY THIS WORKS WITHOUT INSTALLATION:
#  - Uses only Python's built-in math and collections modules
#  - No numpy, no scikit-learn, no compiler needed
#  
#  WHAT YOU CAN TELL YOUR MENTOR:
#  "I implemented TF-IDF vectorization and Naive Bayes classification
#   from scratch using Python's built-in libraries, without depending
#   on external ML frameworks."
# ================================================================

import math
import re
import time
from collections import defaultdict

# ── Training Data (complaint text → crime label) ──────────────
TRAINING_DATA = [
    # Online Fraud
    ("received call from bank asked otp transferred money lost rupees upi payment scam cheated", "Online Fraud"),
    ("someone called pretending sbi asked share otp money debited account google pay fraud", "Online Fraud"),
    ("ordered product online paid never received website disappeared money gone paytm phonepe", "Online Fraud"),
    ("fake customer care called refund asked remote access stole money bank account transfer", "Online Fraud"),
    ("upi fraud transferred money wrong account phonepe gpay scam lost cash rupees", "Online Fraud"),
    ("investment scheme promised returns took money disappeared ponzi fraud rupees", "Online Fraud"),
    ("lottery winner asked pay fees claim prize scam fraud money lost", "Online Fraud"),

    # Phishing
    ("received fake email bank account suspended click link entered password credentials", "Phishing"),
    ("got sms account blocked link clicked entered credentials card details stolen phishing", "Phishing"),
    ("fake amazon email verify account clicked website login password stolen", "Phishing"),
    ("email from fake hdfc bank reset password link phishing website credentials", "Phishing"),
    ("spoofed email looking real entered otp credit card number fake site phishing", "Phishing"),
    ("fake sbi email account verify click link entered details stolen", "Phishing"),

    # Cyberbullying
    ("someone sending abusive messages harassing online threatening me social media bully", "Cyberbullying"),
    ("classmate bullying me online posting humiliating content trolling insulting harassment", "Cyberbullying"),
    ("receiving death threats messages harassment instagram facebook abusive mental torture", "Cyberbullying"),
    ("stalking me online following all accounts sending threatening messages defaming", "Cyberbullying"),
    ("spreading false rumours about me online defamation mental harassment torture bully", "Cyberbullying"),

    # Hacking
    ("gmail account hacked lost access someone changed password recovery unauthorized", "Hacking"),
    ("facebook instagram hacked unauthorized access posting content contacts breach", "Hacking"),
    ("website server hacked data stolen unauthorized access breach compromised", "Hacking"),
    ("someone logged into my account without permission locked out compromised hacked", "Hacking"),
    ("remote access trojan installed keylogger hacked system backdoor unauthorized", "Hacking"),

    # Identity Theft
    ("aadhaar pan card misused loan taken name without knowledge identity stolen document", "Identity Theft"),
    ("someone used my documents fake id impersonation kyc fraud sim swap identity", "Identity Theft"),
    ("credit card issued my name without applying identity misuse personal details stolen", "Identity Theft"),
    ("mobile number ported without consent sim swap fraud bank account drained identity", "Identity Theft"),

    # Ransomware
    ("files encrypted ransomware demand bitcoin pay unlock data held hostage virus", "Ransomware"),
    ("computer locked message pay ransom files cannot open encrypted virus malware", "Ransomware"),
    ("malware attack hospital files encrypted demanded crore rupees ransom locked", "Ransomware"),

    # Social Media Abuse
    ("morphed photos posted instagram facebook without consent obscene images social media", "Social Media Abuse"),
    ("fake profile created my name photos misused social media accounts instagram", "Social Media Abuse"),
    ("private video leaked whatsapp groups youtube without permission social media", "Social Media Abuse"),
    ("obscene posts about me twitter snapchat sharing private content social media abuse", "Social Media Abuse"),

    # Data Breach
    ("personal data leaked dark web private information exposed database hacked records", "Data Breach"),
    ("company data breach customer records stolen personal information sold dark web", "Data Breach"),
    ("aadhaar data leaked online personal details exposed unauthorized access records breach", "Data Breach"),
]


# ================================================================
#  STEP 1: TOKENIZER
#  Splits text into individual words, removes common words
# ================================================================
STOP_WORDS = {"i","me","my","the","a","an","and","or","but","in","on","at","to",
              "for","of","with","by","from","is","was","are","were","be","been",
              "have","has","had","do","did","will","would","could","should","may",
              "might","this","that","these","those","it","its","he","she","they",
              "we","you","who","what","when","where","how","not","no","so","if",
              "as","than","then","just","also","about","after","before","without",
              "someone","some","any","all","more","most","other","such","into"}

def tokenize(text):
    """Convert text to list of meaningful words"""
    words = re.findall(r'\b[a-z]{2,}\b', text.lower())
    return [w for w in words if w not in STOP_WORDS]


# ================================================================
#  STEP 2: TF-IDF (Term Frequency - Inverse Document Frequency)
#  Implemented from scratch using only Python math module
# ================================================================
class TFIDFVectorizer:
    def __init__(self):
        self.vocab = {}          # word → index
        self.idf   = {}          # word → IDF score
        self.num_docs = 0

    def fit(self, documents):
        """Learn vocabulary and IDF scores from training data"""
        self.num_docs = len(documents)
        doc_freq = defaultdict(int)

        # Count how many documents each word appears in
        for doc in documents:
            words = set(tokenize(doc))
            for word in words:
                doc_freq[word] += 1

        # Calculate IDF: log(total_docs / docs_containing_word)
        # Words in fewer docs get HIGHER IDF (more distinctive)
        for word, freq in doc_freq.items():
            self.idf[word] = math.log((self.num_docs + 1) / (freq + 1)) + 1

        # Build vocabulary (all unique words)
        self.vocab = {word: i for i, word in enumerate(self.idf.keys())}

    def transform(self, text):
        """Convert one text document into TF-IDF scores dict"""
        words = tokenize(text)
        if not words:
            return {}

        # TF: count each word in this document
        tf = defaultdict(int)
        for word in words:
            tf[word] += 1

        # Normalize TF by total words
        total = len(words)
        tfidf = {}
        for word, count in tf.items():
            if word in self.idf:
                tfidf[word] = (count / total) * self.idf[word]

        return tfidf


# ================================================================
#  STEP 3: NAIVE BAYES CLASSIFIER
#  Calculates probability of each crime type given the text
# ================================================================
class NaiveBayesClassifier:
    def __init__(self):
        self.class_probs  = {}   # P(crime_type)
        self.word_probs   = {}   # P(word | crime_type)
        self.classes      = []

    def fit(self, tfidf_vectors, labels):
        """Train: learn word probabilities per crime category"""
        self.classes = list(set(labels))

        # Count documents per class
        class_counts = defaultdict(int)
        for label in labels:
            class_counts[label] += 1

        # P(class) = count(class) / total_docs
        total = len(labels)
        self.class_probs = {c: count/total for c, count in class_counts.items()}

        # Word scores per class
        class_word_scores = defaultdict(lambda: defaultdict(float))
        class_totals      = defaultdict(float)

        for vec, label in zip(tfidf_vectors, labels):
            for word, score in vec.items():
                class_word_scores[label][word] += score
                class_totals[label] += score

        # P(word | class) with Laplace smoothing
        vocab_size = len(set(w for vec in tfidf_vectors for w in vec))
        self.word_probs = {}
        for c in self.classes:
            self.word_probs[c] = {}
            total_score = class_totals[c] + vocab_size
            for word in set(w for vec in tfidf_vectors for w in vec):
                self.word_probs[c][word] = (class_word_scores[c].get(word, 0) + 1) / total_score

    def predict(self, tfidf_vec):
        """Predict crime type and confidence for a new complaint"""
        if not tfidf_vec:
            return "Other", 0.0

        scores = {}
        for c in self.classes:
            # Start with log of class probability
            score = math.log(self.class_probs.get(c, 0.001))
            # Add log probability of each word given this class
            for word, tfidf_score in tfidf_vec.items():
                if word in self.word_probs[c]:
                    score += tfidf_score * math.log(self.word_probs[c][word])
            scores[c] = score

        # Find best class
        best_class = max(scores, key=scores.get)

        # Convert log scores to probability (softmax)
        max_score = max(scores.values())
        exp_scores = {c: math.exp(s - max_score) for c, s in scores.items()}
        total_exp  = sum(exp_scores.values())
        confidence = (exp_scores[best_class] / total_exp) * 100

        return best_class, round(confidence, 1)


# ================================================================
#  TRAIN THE MODEL (runs once when app starts)
# ================================================================
print("Training ML model (TF-IDF + Naive Bayes)...")

texts  = [t for t, _ in TRAINING_DATA]
labels = [l for _, l in TRAINING_DATA]

vectorizer  = TFIDFVectorizer()
vectorizer.fit(texts)

train_vectors = [vectorizer.transform(t) for t in texts]

classifier = NaiveBayesClassifier()
classifier.fit(train_vectors, labels)

print(f"Model trained on {len(texts)} examples, {len(vectorizer.vocab)} unique features.")


# ================================================================
#  PUBLIC FUNCTION — called by app.py
# ================================================================
def ml_classify(description):
    """
    Classify a complaint description into a crime type.
    Returns: (crime_type, confidence_percent, triage_ms)
    """
    if not description or len(description.strip()) < 5:
        return "Other", 0, 0

    start = time.time()

    vec        = vectorizer.transform(description)
    crime_type, confidence = classifier.predict(vec)

    elapsed_ms = round((time.time() - start) * 1000, 2)

    return crime_type, confidence, elapsed_ms
