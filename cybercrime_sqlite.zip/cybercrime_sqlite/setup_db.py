import sqlite3, json
print("Setting up database...")
conn=sqlite3.connect("cybercrime.db")
cursor=conn.cursor()
cursor.execute("DROP TABLE IF EXISTS complaints")
cursor.execute("""CREATE TABLE complaints(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    fullname TEXT NOT NULL, email TEXT NOT NULL, phone TEXT,
    city TEXT NOT NULL, crime_type TEXT NOT NULL,
    incident_date TEXT NOT NULL, description TEXT NOT NULL,
    severity TEXT NOT NULL, evidence_file TEXT,
    status TEXT DEFAULT 'Pending',
    ai_confidence INTEGER DEFAULT 0,
    entities_json TEXT,
    priority_score INTEGER DEFAULT 1,
    priority_label TEXT DEFAULT 'Low',
    priority_reason TEXT,
    triage_ms REAL DEFAULT 0,
    submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)""")
samples=[
    ("Rahul Sharma","rahul@gmail.com","9876543210","Pune","Online Fraud","2024-11-15",
     "Someone called claiming to be SBI bank asked OTP transferred Rs 25000 via UPI. Number was 9823456789. They sent link www.sbi-verify.com",
     "High",85,'{"phone_numbers":["9823456789"],"amounts":["Rs 25000"],"urls":["www.sbi-verify.com"]}',8,"Critical","financial loss ₹25,000",1.2),
    ("Priya Patel","priya@gmail.com","9123456780","Mumbai","Phishing","2024-11-20",
     "Fake Amazon email from support@amazon-verify.co clicked http://fake-amazon.com entered password Rs 12000 debited",
     "High",78,'{"emails":["support@amazon-verify.co"],"urls":["http://fake-amazon.com"],"amounts":["Rs 12000"]}',7,"High","financial loss ₹12,000",0.9),
    ("Amit Kulkarni","amit@gmail.com","9988776655","Nashik","Cyberbullying","2024-11-28",
     "Fake Instagram profile created with my photos sending abusive messages to my contacts threatening me",
     "Medium",65,'{}',5,"Medium","Standard assessment",0.8),
    ("Sneha Desai","sneha@gmail.com","9871234560","Aurangabad","Hacking","2024-12-01",
     "Gmail account hacked someone changed password sending messages asking money via UPI snehad@okaxis",
     "High",80,'{"upi_ids":["snehad@okaxis"]}',8,"Critical","account compromise",1.1),
    ("Vikram Joshi","vikram@gmail.com","9765432109","Kolhapur","Identity Theft","2024-12-05",
     "Someone used Aadhaar PAN card to take loan Rs 150000 from NBFC without my knowledge",
     "High",90,'{"amounts":["Rs 150000"]}',9,"Critical","loss ₹150,000",1.4),
    ("Meera Iyer","meera@gmail.com","9654321098","Pune","Online Fraud","2024-12-10",
     "Paid Rs 3500 UPI meera.iyer@ybl to www.cheapdeals99.in product never arrived site down",
     "Medium",70,'{"urls":["www.cheapdeals99.in"],"amounts":["Rs 3500"],"upi_ids":["meera.iyer@ybl"]}',6,"High","financial loss ₹3,500",0.7),
    ("Arjun Nair","arjun@gmail.com","9543210987","Mumbai","Ransomware","2024-12-12",
     "Office laptop files encrypted ransomware demand 0.5 bitcoin contact ransom@protonmail.com cannot access files",
     "High",88,'{"emails":["ransom@protonmail.com"]}',9,"Critical","ransomware",1.3),
    ("Kavya Reddy","kavya@gmail.com","9432109876","Hyderabad","Social Media Abuse","2024-12-15",
     "Morphed photos posted Instagram Facebook threatening call 9876543211 pay Rs 50000 or more photos shared",
     "High",75,'{"phone_numbers":["9876543211"],"amounts":["Rs 50000"]}',8,"Critical","loss ₹50,000",1.0),
    ("Rohan Mehta","rohan@gmail.com","9321098765","Pune","Phishing","2024-12-18",
     "SMS HDFC account blocked clicked http://hdfc-update.net entered credentials Rs 45000 transferred account 987654321012",
     "High",82,'{"urls":["http://hdfc-update.net"],"amounts":["Rs 45000"],"account_numbers":["987654321012"]}',8,"Critical","loss ₹45,000",0.8),
    ("Anita Singh","anita@gmail.com","9210987654","Delhi","Data Breach","2024-12-20",
     "Personal data found dark web phone 9210987654 email anita@gmail.com bank details exposed for sale",
     "Medium",72,'{"phone_numbers":["9210987654"],"emails":["anita@gmail.com"]}',6,"High","data breach",0.6),
]
cursor.executemany("""INSERT INTO complaints
    (fullname,email,phone,city,crime_type,incident_date,description,severity,
     ai_confidence,entities_json,priority_score,priority_label,priority_reason,triage_ms)
    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
    [(s[0],s[1],s[2],s[3],s[4],s[5],s[6],s[7],s[8],s[9],s[10],s[11],s[12],s[13]) for s in samples])
conn.commit(); conn.close()
print("="*50)
print("  SUCCESS! Database ready with ML columns.")
print("  10 complaints added with triage_ms data.")
print("  Now run: python app.py")
print("="*50)
