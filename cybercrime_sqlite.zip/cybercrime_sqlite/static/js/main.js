(function(){
 var d=document.getElementById('description');
 if(d){
  var box=document.getElementById('ai-box'),sel=document.getElementById('crime_type'),cnt=document.getElementById('count'),t;
  function sev(){var r=document.querySelector('input[name=severity]:checked');return r?r.value:'Medium';}
  function run(){
   cnt.textContent=d.value.length+' characters';
   if(d.value.trim().length<15){box.style.display='none';return;}
   var fd=new FormData();fd.append('description',d.value);fd.append('severity',sev());
   fetch('/ai_analyze',{method:'POST',body:fd}).then(function(r){return r.json();}).then(function(j){
    var e=j.entities||{},c='',k;for(k in e){(e[k]||[]).forEach(function(v){c+='<span class="chip">'+k.replace('_',' ')+': '+v+'</span>';});}
    box.innerHTML='<h4>🤖 AI Analysis</h4><b>Crime type:</b> '+j.crime_type+' ('+j.confidence+'% confidence)<br><b>Priority:</b> <span class="bd '+j.priority_label+'">'+j.priority_label+'</span> '+j.priority_score+'/10 — '+j.priority_reason+'<br><b>Evidence found:</b> '+(c||'none yet')+'<br><small>Analysed in '+j.triage_ms+' ms</small>';
    box.style.display='block';
    if(!sel.dataset.manual){for(var i=0;i<sel.options.length;i++){if(sel.options[i].value===j.crime_type)sel.selectedIndex=i;}syncChips();}
   }).catch(function(){});
  }
  function syncChips(){document.querySelectorAll('.chips span').forEach(function(s){s.classList.toggle('on',s.dataset.v===sel.value);});}
  document.querySelectorAll('.chips span').forEach(function(s){s.onclick=function(){sel.value=s.dataset.v;sel.dataset.manual='1';syncChips();};});
  sel.onchange=function(){sel.dataset.manual=sel.value?'1':'';syncChips();};
  d.addEventListener('input',function(){clearTimeout(t);t=setTimeout(run,450);cnt.textContent=d.value.length+' characters';});
  document.querySelectorAll('input[name=severity]').forEach(function(r){r.onchange=run;});
  var f=document.getElementById('evidence'),dr=document.getElementById('drop');
  if(f){dr.onclick=function(){f.click();};f.onchange=function(){if(f.files[0])dr.innerHTML='📎 <b>'+f.files[0].name+'</b>';};
   dr.ondragover=function(e){e.preventDefault();};dr.ondrop=function(e){e.preventDefault();f.files=e.dataTransfer.files;f.onchange();};}
 }
})();
